package blackjack;

import java.io.Serializable;

public interface Blackjackgame extends Serializable {

	interface cards{

	}

	interface disto{

	}

	interface play{

	}

	interface win{

	}

	interface score{

	}

}