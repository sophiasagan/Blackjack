package lib;

public class Input {

	public static int getInt() {
		// TODO Auto-generated method stub
		return 0;
	}

}
