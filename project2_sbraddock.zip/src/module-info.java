/**
 * 
 */
/**
 * @author Sophia
 *
 */
module blackjack {
}